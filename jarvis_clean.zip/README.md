# Jarvis - Personal AI Assistant

> Fast, minimal AI assistant for Windows (16GB RAM)

## Features

- 🎤 **Voice Input** - Faster Whisper STT
- 🗣️ **Voice Output** - Windows Speech TTS
- ⚡ **Fast LLM** - Groq (free tier, ~300ms response)
- 🛠️ **Tools** - Weather, News, Stocks
- 🌐 **Any URL** - Opens any website you say
- 📱 **Apps** - Open calculator, notepad, chrome, spotify

## Quick Start

```bash
# Install dependencies
pip install requests groq edge-tts sounddevice numpy faster-whisper

# Run
python jarvis_fast.py
```

## Usage

```bash
python jarvis_fast.py
```

- Type commands normally
- Type `v` for voice mode
- Say "x" to exit voice mode

## Voice Commands

| Command | Action |
|---------|--------|
| `open youtube` | Opens YouTube |
| `open myflixertv.io` | Opens any URL |
| `open calculator` | Opens calculator |
| `weather` | Get weather |
| `news` | Latest news |
| `stocks reliance` | Stock price |
| `remember [note]` | Save note |
| `what time` | Current time |

## Tech Stack

- **STT**: Faster Whisper (base)
- **LLM**: Groq (llama-3.1-8b-instant) - free
- **TTS**: Windows Speech

## Requirements

- Python 3.10+
- 16GB RAM
- Windows
- Microphone (for voice)

## License

MIT