"""
jarvis_fast.py — Minimal Jarvis that works.
pip install requests
No pyttsx3 needed — uses Windows built-in speech
"""

import os
import re
import subprocess
import webbrowser
import requests
from datetime import datetime

# === LLM CONFIG ===
# Choose: "groq" (fastest, free) or "openrouter" (more options)
LLM_PROVIDER = "groq"

# Get free Groq key: https://console.groq.com
GROQ_API_KEY = "YOUR_GROQ_KEY"  # Replace with your key

# OpenRouter fallback
OPENROUTER_API_KEY = "YOUR_OPENROUTER_KEY"  # Replace with your key

APPS = {
    # Browsers
    "chrome": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "google chrome": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "browser": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "firefox": r"C:\Program Files\Mozilla Firefox\firefox.exe",
    # Media
    "spotify": os.path.expanduser(r"~\AppData\Roaming\Spotify\Spotify.exe"),
    "vlc": r"C:\Program Files\VideoLAN\VLC\vlc.exe",
    "youtube": "https://youtube.com",
    # Code
    "vscode": os.path.expanduser(
        r"~\AppData\Local\Programs\Microsoft VS Code\Code.exe"
    ),
    "visual studio code": os.path.expanduser(
        r"~\AppData\Local\Programs\Microsoft VS Code\Code.exe"
    ),
    # System
    "notepad": "notepad.exe",
    "calculator": "calc.exe",
    "explorer": "explorer.exe",
    "file explorer": "explorer.exe",
    "terminal": "wt.exe",
    "cmd": "cmd.exe",
    "powershell": "powershell.exe",
    "task manager": "taskmgr.exe",
    # Office
    "word": "winword.exe",
    "excel": "excel.exe",
    "powerpoint": "powerpnt.exe",
}

NOTES_FILE = "jarvis_notes.txt"

# ============================================================
#                TOOLS / DATA SOURCES SECTION
#     Add new tools here following the same pattern
# ============================================================


# --- TOOL 1: Weather ---
def tool_weather(query: str) -> str:
    """Get current weather for any city."""
    # Extract city from query
    match = re.search(r"weather (?:in|at)? (.+)", query.lower())
    city = match.group(1).strip() if match else None

    if not city:
        try:
            r = requests.get("https://ipapi.co/json/", timeout=5)
            data = r.json()
            city = data.get("city", "Chennai")
        except:
            city = "Chennai"

    try:
        wr = requests.get(f"https://wttr.in/{city}?format=%C+%t", timeout=10)
        if wr.status_code == 200:
            return f"Weather in {city}: {wr.text.strip()}"
    except:
        pass
    return "Couldn't fetch weather. Check internet."


# --- TOOL 2: News Headlines ---
def tool_news(query: str) -> str:
    """Get latest news headlines."""
    try:
        # Using GNews API (free tier: 100 requests/day)
        r = requests.get(
            "https://gnews.io/api/v4/top-headlines",
            params={"country": "in", "max": 5},
            headers={
                "Authorization": "YOUR_GNEWS_API_KEY"
            },  # Get free key: https://gnews.io
            timeout=10,
        )
        if r.status_code == 200:
            articles = r.json().get("articles", [])
            if articles:
                headlines = [
                    f"{i + 1}. {a['title']}" for i, a in enumerate(articles[:5])
                ]
                return "Latest news: " + " | ".join(headlines)
    except:
        pass

    # Fallback: BBC headlines
    try:
        r = requests.get("https://feeds.bbci.co.uk/news/rss.xml", timeout=10)
        if r.status_code == 200:
            import xml.etree.ElementTree as ET

            root = ET.fromstring(r.text)
            items = root.findall(".//item")
            if items:
                headlines = [
                    items[i].find("title").text for i in range(min(5, len(items)))
                ]
                return "Latest news: " + " | ".join(headlines)
    except:
        pass

    return "Couldn't fetch news. Try again later."


# --- TOOL 3: WorldMonitor App ---
def tool_worldmonitor(query: str) -> str:
    """Get data from worldmonitor.app website."""
    try:
        # Scrape worldmonitor.app (free, no API key)
        r = requests.get("https://worldmonitor.app", timeout=15)
        if r.status_code == 200:
            # Extract key metrics from page
            # This is a placeholder - actual scraping depends on page structure
            return "WorldMonitor: Global markets and indices. Check: https://worldmonitor.app"
    except:
        pass
    return "Couldn't reach WorldMonitor. Try: https://worldmonitor.app"


# --- TOOL 4: Stock Prices (India) ---
def tool_stocks(query: str) -> str:
    """Get stock prices for Indian companies."""
    symbols = {
        "reliance": "RELIANCE",
        "tcs": "TCS",
        "infy": "INFY",
        "infosys": "INFY",
        "hdfc": "HDFCBANK",
        "icici": "ICICIBANK",
        "sbi": "SBIN",
        "airtel": "BHARTIARTL",
    }

    query_lower = query.lower()
    for name, symbol in symbols.items():
        if name in query_lower:
            try:
                r = requests.get(
                    f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}.NS?interval=1d",
                    timeout=10,
                    headers={"User-Agent": "Mozilla/5.0"},
                )
                if r.status_code == 200:
                    data = r.json()
                    result = data.get("chart", {}).get("result", [])
                    if result:
                        price = result[0]["meta"]["regularMarketPrice"]
                        return f"{symbol}: Rs {price}"
            except Exception as e:
                print(f"Stock error: {e}")
            return f"Couldn't fetch {name} stock."

    return "Say a company name: Reliance, TCS, HDFC, etc."


# --- TOOL 5: Your Trained ML Models (FUTURE) ---
def tool_your_model(query: str) -> str:
    """
    ═══════════════════════════════════════════════════════════
    HOW TO ADD YOUR TRAINED MODEL:
    ═══════════════════════════════════════════════════════════

    1. Place your trained model file in: models/ folder
       - .pkl (sklearn), .h5 (Keras), .onnx (ONNX), .pt (PyTorch)

    2. Create a wrapper function like this:

    def tool_house_price(query: str) -> str:
        import joblib
        import pandas as pd

        # Load your model (cache it!)
        if not hasattr(tool_house_price, "_model"):
            tool_house_price._model = joblib.load("models/house_price_model.pkl")

        # Extract features from query
        # Example: "3BHK Chennai 1200sqft"
        bedrooms = 3  # extract from query
        city = "Chennai"  # extract from query
        sqft = 1200  # extract from query

        # Predict
        X = [[bedrooms, sqft, city_encoded]]
        prediction = tool_house_price._model.predict(X)

        return f"Estimated price: ₹{prediction[0]:.2f} lakhs"

    3. Add to TOOLS dict below:
       "house price": tool_house_price,
       "predict": tool_your_model,

    4. The router will auto-detect and call your model!
    ═══════════════════════════════════════════════════════════
    """
    return "Model plugin not ready yet. Train a model and add it to tools!"


# --- TOOL: Custom URLs / Any website ---
def tool_custom_url(query: str) -> str:
    """Open any website user mentions."""
    import re

    # Check for known websites
    urls = {
        "youtube": "https://youtube.com",
        "gmail": "https://gmail.com",
        "twitter": "https://twitter.com",
        "instagram": "https://instagram.com",
        "linkedin": "https://linkedin.com",
        "github": "https://github.com",
        "drive": "https://drive.google.com",
        "calendar": "https://calendar.google.com",
        "maps": "https://maps.google.com",
        "news": "https://news.google.com",
        "reddit": "https://reddit.com",
        "tradingview": "https://tradingview.com",
        "zerodha": "https://kite.zerodha.com",
    }

    query_lower = query.lower()

    # Check known URLs first (whole word match)
    for name, url in urls.items():
        if name in query_lower:
            webbrowser.open(url)
            return f"Opening {name}..."

    # Extract URLs - ignore https://, http://, www. prefixes
    clean_query = (
        query_lower.replace("https://", "").replace("http://", "").replace("www.", "")
    )

    # Find any .com, .io, .in, .org, .net pattern
    url_match = re.search(r"(\S+\.(?:com|io|in|org|net|co))", clean_query)
    if url_match:
        possible_url = url_match.group(1)
        # Remove any trailing punctuation
        possible_url = possible_url.rstrip(".,!?;")
        full_url = "https://" + possible_url
        webbrowser.open(full_url)
        return f"Opening {possible_url}..."

    return None


# ============================================================
#          TOOLS REGISTRY (auto-detected by router)
# ============================================================

TOOLS = {
    # Data tools
    "weather": tool_weather,
    "forecast": tool_weather,
    "news": tool_news,
    "headlines": tool_news,
    "worldmonitor": tool_worldmonitor,
    "stocks": tool_stocks,
    "share market": tool_stocks,
    "nifty": tool_stocks,
    "sensex": tool_stocks,
    "predict": tool_your_model,
    "model": tool_your_model,
    "house price": tool_your_model,
    # URL tools
    "youtube": tool_custom_url,
    "gmail": tool_custom_url,
    "github": tool_custom_url,
    "drive": tool_custom_url,
    "calendar": tool_custom_url,
    "maps": tool_custom_url,
    "tradingview": tool_custom_url,
    "zerodha": tool_custom_url,
    "upstox": tool_custom_url,
}

# ============================================================
#                  CORE FUNCTIONS
# ============================================================

# Track if Jarvis is speaking
_speaking = False


def speak(text: str):
    """Windows Speech - reliable, no music app opens."""
    global _speaking
    print(f"\nJarvis: {text}\n")
    import subprocess
    import sys

    _speaking = True

    if sys.platform == "win32":
        # Use PowerShell SAPI - simple and reliable
        cmd = f'''
        Add-Type -AssemblyName System.Speech
        $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
        $synth.Rate = 1
        $synth.Speak("{text.replace('"', '`"')}")
        '''
        subprocess.Popen(
            ["powershell", "-WindowStyle", "Hidden", "-Command", cmd],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=0x08000000,
        )

    # Don't wait - just mark as speaking briefly
    import time

    time.sleep(0.5)
    _speaking = False


def ask_llm(text: str) -> str:
    """Groq or OpenRouter LLM."""
    import groq

    if LLM_PROVIDER == "groq":
        try:
            client = groq.Groq(api_key=GROQ_API_KEY)
            response = client.chat.completions.create(
                model="llama-3.1-8b-instant",  # Fast & free
                messages=[
                    {
                        "role": "system",
                        "content": "You are Jarvis. Be concise. Max 2 sentences.",
                    },
                    {"role": "user", "content": text},
                ],
                max_tokens=150,
                temperature=0.7,
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"Groq error: {e}"

    # Fallback to OpenRouter
    try:
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": "openai/gpt-4o-mini",
                "messages": [
                    {
                        "role": "system",
                        "content": "You are Jarvis. Be concise. Max 2 sentences.",
                    },
                    {"role": "user", "content": text},
                ],
                "max_tokens": 150,
            },
            timeout=15,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"API error: {e}"


def route(text: str) -> str:
    t = text.lower().strip()

    # === 1. CHECK FOR APP COMMANDS FIRST (before TOOLS) ===
    # "open calculator", "open spotify", "open chrome"
    match = re.search(r"open (.+)", t)
    if match:
        app_name = match.group(1).strip()
        for key, path in APPS.items():
            if key in app_name:
                if path.startswith("http"):
                    webbrowser.open(path)
                else:
                    subprocess.Popen(path, shell=True)
                return f"Opening {key}."
        # Try URL matches
        return tool_custom_url(text)

    match = re.search(r"launch (.+)", t)
    if match:
        app_name = match.group(1).strip()
        for key, path in APPS.items():
            if key in app_name:
                if path.startswith("http"):
                    webbrowser.open(path)
                else:
                    subprocess.Popen(path, shell=True)
                return f"Opening {key}."

    # === 2. CHECK TOOLS (weather, news, stocks, etc.) ===
    for keyword, tool_func in TOOLS.items():
        if keyword in t:
            return tool_func(text)

    # === 3. LOCAL COMMANDS ===
    if re.search(r"what(('s| is) the)? time", t):
        return f"It's {datetime.now().strftime('%I:%M %p')}."

    if re.search(r"today|current date", t):
        return f"Today is {datetime.now().strftime('%A, %B %d, %Y')}."

    match = re.search(r"^remember |^note[:\s]+", t)
    if match:
        content = text.split(maxsplit=1)[-1]
        with open(NOTES_FILE, "a") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M')}] {content}\n")
        return f"Noted: {content}"

    if re.search(r"read notes|show notes", t):
        if os.path.exists(NOTES_FILE):
            with open(NOTES_FILE) as f:
                lines = [l.strip() for l in f if l.strip()]
            if lines:
                return "Notes: " + ". ".join(lines[-3:])
        return "No notes yet."

    # === 4. CHECK APP NAMES DIRECTLY (calculator, spotify, etc.) ===
    for key, path in APPS.items():
        if key in t:
            if path.startswith("http"):
                webbrowser.open(path)
            else:
                subprocess.Popen(path, shell=True)
            return f"Opening {key}."

    # === 5. SEARCH ===
    if re.search(r"search|google", t):
        match = re.search(r"search (.+)|google (.+)", t)
        if match:
            query = match.group(1) or match.group(2)
            webbrowser.open(f"https://google.com/search?q={query}")
            return f"Searching..."

    # === 6. FALLBACK TO LLM ===
    return ask_llm(text)


def listen_voice(timeout: float = 15.0) -> str:
    """Faster Whisper - much longer buffer to avoid echo."""
    global _speaking

    from faster_whisper import WhisperModel
    import sounddevice as sd
    import numpy as np
    import threading
    import time

    # Store last Jarvis response for echo check
    last_jarvis_response = getattr(listen_voice, "_last_response", "")

    try:
        if not hasattr(listen_voice, "_model"):
            print("Loading Whisper model...")
            listen_voice._model = WhisperModel(
                "base", device="cpu", compute_type="int8"
            )

        # Wait for Jarvis to finish + MUCH longer buffer (5 seconds)
        while _speaking:
            time.sleep(0.1)
        time.sleep(5.0)  # 5 seconds - let all audio clear

        # DON'T speak "Listening..." - just print
        print("(Listening... speak now)")

        recording = []
        started = [False]
        silence_count = [0]
        lock = threading.Lock()

        def audio_callback(indata, frames, time, status):
            if status:
                return
            audio_data = indata.flatten()
            volume = np.abs(audio_data).mean()

            # Higher threshold to avoid TTS echo
            if volume > 0.025:
                with lock:
                    started[0] = True
                    recording.append(audio_data.copy())
            elif started[0]:
                if volume > 0.005:
                    recording.append(audio_data.copy())
                else:
                    silence_count[0] += 1

        with sd.InputStream(
            samplerate=16000,
            channels=1,
            dtype="float32",
            callback=audio_callback,
            blocksize=1024,
        ):
            start = time.time()
            while time.time() - start < timeout:
                time.sleep(0.05)
                with lock:
                    if started[0] and silence_count[0] > 100:  # 5 seconds silence
                        break

        if not recording:
            return None

        audio_data = np.concatenate(recording)
        if np.abs(audio_data).max() > 0:
            audio_data = audio_data / np.abs(audio_data).max()

        segments, info = listen_voice._model.transcribe(audio_data, language="en")
        text = " ".join([seg.text for seg in segments]).strip()

        # Echo check - ignore if too similar to last Jarvis response
        if text and last_jarvis_response:
            text_lower = text.lower()
            last_lower = last_jarvis_response.lower()
            common_words = set(last_lower.split()) & set(text_lower.split())
            # If more than 3 common words, likely echo
            if len(common_words) > 3:
                print(f"Echo detected, ignoring: {text}")
                return None

        # Save for next echo check
        listen_voice._last_response = text

        print(f"Heard: {text}")
        return text if text else None

    except Exception as e:
        print(f"Whisper error: {e}")
        return None

        audio_data = np.concatenate(recording)
        if np.abs(audio_data).max() > 0:
            audio_data = audio_data / np.abs(audio_data).max()

        segments, info = listen_voice._model.transcribe(audio_data, language="en")
        text = " ".join([seg.text for seg in segments]).strip()

        print(f"Heard: {text}")
        return text if text else None

    except Exception as e:
        print(f"Whisper error: {e}")
        return None

        audio_data = np.concatenate(recording)
        if np.abs(audio_data).max() > 0:
            audio_data = audio_data / np.abs(audio_data).max()

        segments, info = listen_voice._model.transcribe(audio_data, language="en")
        text = " ".join([seg.text for seg in segments]).strip()

        # Echo check: ignore if similar to last spoken
        if text and last_spoken:
            text_lower = text.lower()
            last_lower = last_spoken.lower()
            # If >50% similarity, likely echo
            words_last = set(last_lower.split())
            words_text = set(text_lower.split())
            if len(words_last & words_text) > len(words_text) * 0.5:
                print(f"Echo detected, ignoring: {text}")
                return None

        print(f"Heard: {text}")
        return text if text else None

    except Exception as e:
        print(f"Whisper error: {e}")
        return None

        if not recording:
            return None

        audio_data = np.concatenate(recording)
        if np.abs(audio_data).max() > 0:
            audio_data = audio_data / np.abs(audio_data).max()

        segments, info = listen_voice._model.transcribe(audio_data, language="en")
        text = " ".join([seg.text for seg in segments]).strip()

        print(f"Heard: {text}")
        return text if text else None

    except Exception as e:
        print(f"Whisper error: {e}")
        return None


def main():
    print("=" * 40)
    print("  JARVIS — Fast Mode")
    print("  Type command, or V for continuous voice")
    print("  Press X to exit voice mode, Ctrl+C to quit")
    print("=" * 40)
    speak("Jarvis online.")

    voice_mode = False

    while True:
        try:
            if voice_mode:
                print("Listening...")
                user = listen_voice()
                if user:
                    print(f"You: {user}")
                    if user.lower() in ("x", "exit voice", "stop"):
                        voice_mode = False
                        speak("Voice mode off.")
                        continue
                    response = route(user)
                    speak(response)
                else:
                    speak("Didn't catch that.")
            else:
                user = input("You: ").strip()
                if not user:
                    continue
                if user.lower() == "v":
                    voice_mode = True
                    continue
                if user.lower() in ("quit", "exit", "bye"):
                    speak("Goodbye.")
                    break
                response = route(user)
                speak(response)
        except KeyboardInterrupt:
            speak("Shutting down.")
            break


if __name__ == "__main__":
    main()
